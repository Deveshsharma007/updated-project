import React from "react";
import "./Card.css";

export const AccountCard = (props) => {
  return (
    <div className="container2">
      <div className="card2" style={{ width: "18rem" }}>
        <span className="card-body" style={{padding:'10px'}}>
          <h5 className="card-title">{props.details.accountNumber}</h5>
          <h6 className="card-subtitle">
            Balance : {props.details.balance}
          </h6>
          <h6 className="card-subtitle ">Bank Name : {props.details.accountStatus}</h6>
          <h6 className="card-subtitle ">
            Branch : {props.details.balance}
          </h6>
          <h6 className="card-subtitle ">
            IFSC : {props.details.ifscCode}
          </h6>
        </span>
      </div>
    </div>
  );
};

export default AccountCard;
