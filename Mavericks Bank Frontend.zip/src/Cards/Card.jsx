import React from "react";
import "./Card.css";
import { Link } from "react-router-dom";

export const Card = (props) => {
  return (    
    <div className="container1">
      {props.details.map((value,index)=>(
      <div className="card" style={{width:'18rem'}} key={index}>
  <span className="card-body">
    <h5 className="card-title">{value.accountNumber}</h5>
    <h6 className="card-subtitle">{value.accountType}</h6>
    <h6>{value.accountStatus}</h6>
    {value.accountStatus === "ACTIVE" && (
      <Link to={`account/${value.accountNumber}`}><button type="button" className="btn btn-primary">Check</button></Link>                  
                )}
  </span>
</div>
))}
    </div>
  );
};

export default Card;
