import React, { useEffect, useState } from 'react';
import "./Card.css";
import { Link, useParams } from 'react-router-dom';
import { useAuth } from 'C:/Users/2000123548/Downloads/Mavericks-Bank-Project-folder/Mavericks-Bank-Project-folder/src/Components/AuthContext.jsx';
import toast from 'react-hot-toast';
import CustomerService from '../Services/CustomerService';
import EmployeeService from '../Services/EmployeeService';

export const EmpCard = (props) => {
    const [customerArray, setCustomerArray] = useState([]);
    const { employeeId } = useParams();
    const [transactions, setTransactions] = useState([]);
    const [customer, setCustomer] = useState([]);
    const {token}=useAuth();

    const getCustomerById = (customerId) => {
        CustomerService.getCustomerById(customerId,token).then((response) => {
            setCustomer(response.data);
            console.log("Customer Details :", response.data);
        }).catch((error) => { console.log(error) });
    }

    const handleCustomerCheck = (e, customerId) => {
        e.preventDefault();
        console.log("Customer Id inside handle check function:- ", customerId);
        getCustomerById(customerId);
    }
    const fetchAllAccounts = () => {
        CustomerService.getAllAccounts(token)
            .then((response) => {
                console.log("Response Received from API:- ", response.data);
                setCustomerArray(response.data);
            })
            .catch((error) => {
                console.log(error);
            });
    }
    useEffect(() => {
        fetchAllAccounts();
        getAllTransactions();
    }, []);
  
    const getAllTransactions = () => {
        EmployeeService.allTransactions(token)
            .then((response) => {
                setTransactions(response.data);
                console.log("All Transactions are:- ", response.data);
            });
    } 

    const handleActivate = (e, number) => {
        e.preventDefault();
        console.log("Id is:- ", number);
        EmployeeService.activateAccount(number,token).then((response) => {
            console.log("response from api:- ", response.data);
            toast.success(response.data);
            fetchAllAccounts();
        }).catch((error) => { console.log(error) })

    }

    const handleClose = (e, number) => {
        e.preventDefault();
        console.log("Id is:- ", number);
        EmployeeService.closeAccount(number,token).then((response) => {
            console.log("response from api:- ", response.data);
            toast.success(response.data);
            fetchAllAccounts();
        }).catch((error) => { console.log(error) })
    }


  return (
    <div className="container3">
      {props.details.map((value, index) => (
        <div className="card-3" style={{ width: "18rem" }} key={index}>
          <span className="card-body">
            <h5 className="card-title">Customer ID: {value.customerId}</h5>
            <h6 className="card-subtitle">Name: {value.customerName}</h6>
            <h6>Account Number: {value.accountNumber}</h6>
            <h6>Type: {value.accountType}</h6>
            <h6>Balance: {value.accountBalance}</h6>
            <h6>Status: {value.accountStatus}</h6>
            <button
              className="btn btn-primary"
              onClick={(e) => {
                handleActivate(e, value.accountNumber);
              }}
              disabled={
                value.accountStatus === "CLOSED" ||
                value.accountStatus === "CLOSE_REQUEST" ||
                value.accountStatus === "ACTIVE"
              }
            >
              Activate
            </button>
            <button
              className="btn btn-danger"
              onClick={(e) => {
                handleClose(e, value.accountNumber);
              }}
              disabled={
                value.accountStatus === "CLOSED" ||
                value.accountStatus === "INACTIVE"
              }
            >
              Close
            </button>
            <Link to={`/employeeaccountdashboard/${value.accountNumber}`}>
              <button className="btn btn-primary">Check</button>
            </Link>
            <button
              type="button"
              className="btn btn-primary"
              data-bs-toggle="modal"
              data-bs-target="#exampleModal"
              onClick={(e) => {
                handleCustomerCheck(e, value.customerId);
              }}
            >
              Check
            </button>
          </span>
        </div>
      ))}
    </div>
  );
};

export default EmpCard;
