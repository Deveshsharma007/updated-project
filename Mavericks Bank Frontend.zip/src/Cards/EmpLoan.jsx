import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import EmployeeService from "../Services/EmployeeService";
import toast from "react-hot-toast";
import { useAuth } from "C:/Users/2000123548/Downloads/Mavericks-Bank-Project-folder/Mavericks-Bank-Project-folder/src/Components/AuthContext.jsx";
import { useNavigate } from "react-router-dom";

const EmpLoan = (props) => {
  const [loanList, setLoanList] = useState([]);
  const [loanId, setLoanId] = useState([]);
  const { token } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    fetchLoanList();
  }, []);

  const fetchLoanList = () => {
    EmployeeService.allLoanApplications(token)
      .then((response) => {
        console.log("Response from Api:- ", response.data);
        setLoanList(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const handleApprove = (e, loanId) => {
    EmployeeService.approveLoan(loanId, token)
      .then((response) => {
        console.log("Response from Api:- ", response.data);
        toast.success(response.data);
        fetchLoanList();
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const handleReject = (e, loanId) => {
    EmployeeService.rejectLoan(loanId, token)
      .then((response) => {
        console.log("Response from Api:- ", response.data);
        toast.success(response.data);
        fetchLoanList();
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <div className="container3">
      {props.details.map((value, index) => (
        <div className="card-3" style={{ width: "18rem" }} key={index}>
          <span className="card-body">
            <h5 className="card-title">Loan ID: {value.loanID}</h5>
            <h6 className="card-subtitle">Name: {value.loanName}</h6>
            <h6>Account Number: {value.accountNumber}</h6>
            <h6>Interest: {value.interestRate}</h6>
            <h6>Tenure: {value.tenure}</h6>
            <h6>Status: {value.loanStatus}</h6>
            <h6>Amount: {value.loanAmount}</h6>
            <button
              className="btn btn-primary"
              onClick={(e) => {
                handleApprove(e, value.loanID);
              }}
              disabled={
                value.loanStatus === "REJECTED" || value.loanStatus === "APPROVED"
              }
            >
              Approve
            </button>&nbsp;&nbsp;&nbsp;&nbsp;
            <button
              className="btn btn-danger"
              onClick={(e) => {
                handleReject(e, value.loanID);
              }}
              disabled={
                value.loanStatus === "REJECTED" || value.loanStatus === "APPROVED"
              }
            >
              Reject
            </button>
          </span>
        </div>
      ))}
    </div>
  );
};

export default EmpLoan;
