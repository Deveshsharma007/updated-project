import React from 'react'

export const LoanCard = (props) => {
  return (
    <div className="container1">
      {props.details.map((value,index)=>(
      <div className="card" style={{width:'18rem'}} key={index}>
  <span className="card-body">
    <h5 className="card-title">Loan ID: {value.loanId}</h5>
    <h6>Loan Type: {value.loanName}</h6>
    <h6>Loan Amount: {value.loanAmount}</h6>
    <h6>Interest: {value.interestRate}</h6>
    <h6>Tenure: {value.tenure}</h6>
    <h6>Status: {value.loanStatus}</h6>
    </span>
</div>
))}
    </div>
  )
}
export default LoanCard;
