import React from 'react'

export const TransactionCard = (props) => {
  return (
    <div className="container3">
      {props.details.map((value,index)=>(
      <div className="card-3" style={{width:'18rem'}} key={index}>
  <span className="card-body">
    <h5 >Transaction ID: {value.transactionId}</h5>
    <h6 >Beneficiary Account Number: {value.beneficiaryAccountNumber}</h6>
    <h6>Date: {value.date}</h6>
    <h6>Amount: {value.transactionAmount}</h6>
    <h6>Transaction Type: {value.transactionType}</h6>    
  </span>
</div>
))}
    </div>
  )
}

export default TransactionCard;