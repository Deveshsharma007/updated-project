import React, { useEffect, useState } from 'react';
import './EmpProfile.css';
import AdminService from '../Services/AdminService';
import { useParams } from 'react-router-dom';
import { useAuth } from './AuthContext';
import { useNavigate } from 'react-router-dom';

export const EmpProfile = () => {
    const [employee,setemployee]=useState({});
    const { employeeId } = useParams();
    const {token}=useAuth();
    const navigate=useNavigate();

    useEffect(() => {
        find();
    }, []);

   const find=()=>{
    console.log("Finding employee by id=",employeeId);
        AdminService.findEmployee(employeeId,token).then((response) => {
            setemployee(response.data);
            console.log("Employee Details are :", response.data);
        }).catch((error) => { console.log(error) });
    }

    const goBack=()=>{
      navigate(-1);
  }

  return (
    <div className='emp-profile'>
      <div style={{margin: '15px',
                float: 'right'}}><button className='btn btn-primary' onClick={goBack}><h3><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-arrow-left-circle" viewBox="0 0 16 16">
                <path fillRule="evenodd" d="M1 8a7 7 0 1 0 14 0A7 7 0 0 0 1 8m15 0A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-4.5-.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
              </svg></h3></button></div>
        <h1>Employee Profile</h1>
        <div className='emp-card'>
        <div className="card-container" style={{ height: '50vh', width:'50vh' }}>
        <div className="card-content">
          <p>Employee Name : {employee.employeeName}</p>
          <p>Employee Id : {employee.employeeId}</p>
          <p>Phone Number : {employee.phoneNumber}</p>
          <p>Email : {employee.email}</p>
          <p>Age : {employee.age}</p>
          <p>PanCard : {employee.panCardNumber}</p>
          <p>Address : {employee.address}</p>
          <p>Status : {employee.employeeStatus}</p>
        </div>
      </div>
        </div>
    </div>
   )
}

export default EmpProfile;