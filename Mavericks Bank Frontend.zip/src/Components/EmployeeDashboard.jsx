import React, { useEffect, useState } from 'react';
import './EmployeeDashboard.css';
import CustomerService from '../Services/CustomerService';
import EmployeeService from '../Services/EmployeeService';
import { Link, useParams } from 'react-router-dom';
import { useAuth } from './AuthContext';
import EmpCard from '../Cards/EmpCard';

const EmployeeDashboard = () => {
    const [customerArray, setCustomerArray] = useState([]);
    const { employeeId } = useParams();
    const [transactions, setTransactions] = useState([]);
    const [customer, setCustomer] = useState([]);
    const {token}=useAuth();   

    const fetchAllAccounts = () => {
        CustomerService.getAllAccounts(token)
            .then((response) => {
                console.log("Response Received from API:- ", response.data);
                setCustomerArray(response.data);
            })
            .catch((error) => {
                console.log(error);
            });
    }

    useEffect(() => {
        fetchAllAccounts();
        getAllTransactions();
    }, []);
   

    const getAllTransactions = () => {
        EmployeeService.allTransactions(token)
            .then((response) => {
                setTransactions(response.data);
                console.log("All Transactions are:- ", response.data);
            });
    } 


    return (
        <div className='background-image'>
            <div className='employee-dash'>                
                <div><button className="btn btn-primary" style={{
                margin: '15px',
                float: 'left'
            }}
                type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample" aria-controls="offcanvasExample">
                <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fillRule="currentColor"
                    className="bi bi-list"
                    viewBox="0 0 16 16"
                >
                    <path
                        fillRule="evenodd"
                        d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5m0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5m0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5"
                    />
                </svg>Options
            </button></div>

            <div className="offcanvas offcanvas-bottom offcanvas-md"  id="offcanvasExample" aria-labelledby="offcanvasExampleLabel" style={{marginBottom:'7%'}}>
                <div className="offcanvas-header">
                    <h5 className="offcanvas-title" id="offcanvasExampleLabel">Services</h5>
                </div>
                <div className="offcanvas-body" >
                    <div className='btn btn-group-vertical' >                    
                      <Link to={`/employeeloandashboard/${employeeId}`}>
                      <button type="button"
                      className='btn btn-primary float-lg-start'
                      data-bs-dismiss="offcanvas" style={{ margin: '10px',color:'white' }}>Loan Applications</button></Link>                   
                    </div>
                    <div>
                        <Link to={`/employeeprofile/${employeeId}`}>
                        <button type='button' className='btn btn-primary float-lg-start'
                       data-bs-dismiss="offcanvas">
                            Profile</button></Link>
                    </div>
                </div>
            </div>

                <h2>Employee Dashboard</h2>

<div className='card-data'>
    <EmpCard details={customerArray} />
</div>

            </div>

            {/* <!-- Modal --> */}
            <div
                className="modal fade"
                id="exampleModal"
                aria-labelledby="exampleModalLabel"
                aria-hidden="true" >
                <div className="modal-dialog">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h3 className="modal-title fs-5" id="exampleModalLabel">
                                Customer Details
                            </h3>
                            <button
                                type="button"
                                className="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                            ></button>
                        </div>
                        <div className="modal-body">
                            <table className='table table-borderless'>
                                <thead>
                                    <tr>
                                        <td style={{ backgroundColor: "#566822", color: "white" }}>Customer Id</td>
                                        <td style={{ backgroundColor: "#566822", color: "white" }}>Customer Name</td>
                                        <td style={{ backgroundColor: "#566822", color: "white" }}>Phone Number</td>
                                        <td style={{ backgroundColor: "#566822", color: "white" }}>Gender</td>
                                        <td style={{ backgroundColor: "#566822", color: "white" }}>Email</td>
                                        <td style={{ backgroundColor: "#566822", color: "white" }}>Pan Card Number</td>
                                        <td style={{ backgroundColor: "#566822", color: "white" }}>Aadhar Number</td>
                                        <td style={{ backgroundColor: "#566822", color: "white" }}>Address</td>
                                        <td style={{ backgroundColor: "#566822", color: "white" }}>Date of Birth</td>
                                        <td style={{ backgroundColor: "#566822", color: "white" }}>Age</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>{customer.customerId}</td>
                                        <td>{customer.customerName}</td>
                                        <td>{customer.phoneNumber}</td>
                                        <td>{customer.gender}</td>
                                        <td>{customer.email}</td>
                                        <td>{customer.panNumber}</td>
                                        <td>{customer.aadharNumber}</td>
                                        <td>{customer.address}</td>
                                        <td>{customer.dateOfBirth}</td>
                                        <td>{customer.age}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div className="modal-footer">
                            <button
                                type="button"
                                className="btn btn-danger"
                                data-bs-dismiss="modal"
                            >
                                Close
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default EmployeeDashboard
