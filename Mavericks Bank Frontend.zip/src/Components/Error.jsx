import React from 'react';
import './Error.css';

export const Error = () => {
  return (
    <div className='error'>
        <h1>404 NOT FOUND</h1>
        <h3>Bad Request</h3>
    </div>
  )
}
export default Error;