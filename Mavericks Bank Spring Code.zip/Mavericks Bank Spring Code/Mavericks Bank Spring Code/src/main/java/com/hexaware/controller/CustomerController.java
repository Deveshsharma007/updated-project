package com.hexaware.controller;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.customexceptions.AccountAlreadyExistsException;
import com.hexaware.customexceptions.ResourceNotFoundException;
import com.hexaware.dto.CustomerDto;
import com.hexaware.entity.Customer;
import com.hexaware.service.CustomerService;

import jakarta.validation.Valid;

@CrossOrigin("*")
@RestController
@RequestMapping("/api/v1/bankapp")
public class CustomerController {
	private CustomerService customerService;
	public final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	public CustomerController(CustomerService customerService) {
		super();
		this.customerService = customerService;
	}
	
	@PostMapping("/register/addCustomer")
	public ResponseEntity<CustomerDto> createCustomer(@Valid@RequestBody CustomerDto c) throws AccountAlreadyExistsException
	{
		return ResponseEntity.ok(customerService.createCustomer(c));
	}

	@GetMapping("/searchbyname")
	public ResponseEntity <List<Customer>> findBycustomerNameContaining(@RequestParam String name)
	{
		List<Customer>obj=customerService.findBycustomerNameContaining(name);
		if(obj.isEmpty())
		{
			LOGGER.log(Level.INFO,"record empty");
		}
		obj.forEach((p)->{LOGGER.log(Level.INFO,"records"+p);});
		//LOGGER.log(Level.INFO, "records found containing text mouse");
		return ResponseEntity.ok(obj);
	}
	
	@PreAuthorize("hasAuthority('ROLE_ADMIN') or hasAuthority('ROLE_EMP') or hasAuthority('ROLE_USER')")
	@GetMapping("/searchbyid/{id}")
	public ResponseEntity<CustomerDto> findCustomerByid(@PathVariable long id) throws ResourceNotFoundException
	{
				return ResponseEntity.ok(customerService.findCustomerByid(id));
	}
	
	@DeleteMapping("/deletebyid/{id}")
	public void deleteCustomerById(@PathVariable long id)
	{
		customerService.deleteCustomerById(id);
		LOGGER.log(Level.INFO, "Customer Deleted With Id:"+id);
		
	}
}
