package com.hexaware.customexceptions;

import java.net.http.HttpHeaders;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class GlobalExceptionController extends ResponseEntityExceptionHandler{
	@ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorDetails>handleResourceNotFoundException(ResourceNotFoundException ex,WebRequest w){
   	 ErrorDetails e=new ErrorDetails(LocalDateTime.now(),ex.getMessage(),w.getDescription(false),"HttpStatus.NOT_FOUND");
		return new ResponseEntity<>(e,HttpStatus.NOT_FOUND);
		}
	/*@ExceptionHandler(NameAlreadyExistException.class)
	public ResponseEntity<ErrorDetails>handleNameAlreadyExistException(NameAlreadyExistException ex,WebRequest w){
	   	 ErrorDetails e=new ErrorDetails(LocalDateTime.now(),ex.getMessage(),w.getDescription(false),"Product Name Already Exists");
			return new ResponseEntity<>(e,HttpStatus.NOT_FOUND);
			}*/

	protected ResponseEntity<Object> handleMethodArgumentNotValid(
			MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
		Map<String,String> errors=new HashMap();
		List<ObjectError> errorList=ex.getBindingResult().getAllErrors();
		errorList.forEach((error)->{
			String fieldName=((FieldError)error).getField();
			String message=error.getDefaultMessage();
			errors.put(fieldName, message);
		});
				return new ResponseEntity<>(errors,HttpStatus.BAD_REQUEST);
		//return handleExceptionInternal(ex, null, headers, status, request);
	}
	@ExceptionHandler(AccountAlreadyExistsException.class)
	public ResponseEntity<ErrorDetails>handleAccountAlreadyExistsException(AccountAlreadyExistsException ex,WebRequest w)
	{
		ErrorDetails e=new ErrorDetails(LocalDateTime.now(),ex.getMessage(),w.getDescription(false),"HttpStatus.FORBIDDEN");
		return new ResponseEntity<>(e,HttpStatus.FORBIDDEN);
	}
	
	@ExceptionHandler(BadRequestException.class)
	public ResponseEntity<ErrorDetails>BadRequestException(BadRequestException ex,WebRequest w){
		ErrorDetails e=new ErrorDetails(LocalDateTime.now(),ex.getMessage(),w.getDescription(false),"HttpStatus.BAD_REQUEST");
		return new ResponseEntity<>(e,HttpStatus.BAD_REQUEST);
	}

}
