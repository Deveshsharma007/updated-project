package com.hexaware.customexceptions;

public class UsernameAlreadyExistsException extends Exception {
	private String message;
	public UsernameAlreadyExistsException(String message){
		super(message);
		this.message = message;
	}
}
