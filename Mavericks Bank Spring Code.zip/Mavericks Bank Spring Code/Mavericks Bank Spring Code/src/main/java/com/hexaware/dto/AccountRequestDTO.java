package com.hexaware.dto;
//Opening a new account
public class AccountRequestDTO {

	private String accountType;
	//private double accountBalance;
	
	public AccountRequestDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public AccountRequestDTO(String accountType) {
		super();
		this.accountType = accountType;
	}


	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	

	@Override
	public String toString() {
		return "AccountRequestDTO [accountType=" + accountType + "]";
	}
	

}
