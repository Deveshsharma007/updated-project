package com.hexaware.dto;
//Display transaction details
import java.time.LocalDate;

import com.hexaware.enums.TransactionType;

public class AllTransactionDTO {
	private long transactionID;
	private LocalDate date;
	private TransactionType transactionType;
	private double transactionAmount;
	private long beneficiaryAccountNumber;
	private long accountNumber;
	public AllTransactionDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public long getTransactionID() {
		return transactionID;
	}
	
	public AllTransactionDTO(long transactionID, LocalDate date, TransactionType transactionType,
			double transactionAmount, long beneficiaryAccountNumber, long accountNumber) {
		super();
		this.transactionID = transactionID;
		this.date = date;
		this.transactionType = transactionType;
		this.transactionAmount = transactionAmount;
		this.beneficiaryAccountNumber = beneficiaryAccountNumber;
		this.accountNumber = accountNumber;
	}
	public void setTransactionID(long transactionID) {
		this.transactionID = transactionID;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public TransactionType getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(TransactionType transactionType) {
		this.transactionType = transactionType;
	}
	public double getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public long getBeneficiaryAccountNumber() {
		return beneficiaryAccountNumber;
	}
	public void setBeneficiaryAccountNumber(long beneficiaryAccountNumber) {
		this.beneficiaryAccountNumber = beneficiaryAccountNumber;
	}
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	@Override
	public String toString() {
		return "AllTransactionDTO [transactionID=" + transactionID + ", date=" + date + ", transactionType="
				+ transactionType + ", transactionAmount=" + transactionAmount + ", beneficiaryAccountNumber="
				+ beneficiaryAccountNumber + ", accountNumber=" + accountNumber + "]";
	}
	
}
