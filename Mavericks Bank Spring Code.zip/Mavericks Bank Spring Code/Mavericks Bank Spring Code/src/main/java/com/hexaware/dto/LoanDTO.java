package com.hexaware.dto;
//loan request DTO
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class LoanDTO {
	@NotNull
    @Positive(message = "Loan amount must be greater than 0")
	private double loanAmount;
	@NotNull
	private double tenure;
	public LoanDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LoanDTO(double loanAmount, double tenure) {
		super();
		this.loanAmount = loanAmount;
		this.tenure = tenure;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	public double getTenure() {
		return tenure;
	}
	public void setTenure(double tenure) {
		this.tenure = tenure;
	}
	@Override
	public String toString() {
		return "LoanDTO [loanAmount=" + loanAmount + ", tenure=" + tenure + "]";
	}
	

}
