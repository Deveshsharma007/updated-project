package com.hexaware.dto;
import jakarta.validation.constraints.Min;
//transafer dto
import jakarta.validation.constraints.NotNull;

public class TransactionTransferDTO {
	@NotNull
    @Min(value=500,message = "Transaction amount must be greater than 500")
	private double transactionAmount;
	private long beneficiaryAccountNumber;
	//private TransactionType transactiontype;
	public TransactionTransferDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public TransactionTransferDTO(double transactionAmount, long beneficiaryAccountNumber/*,
			TransactionType transactiontype*/) {
		super();
		this.transactionAmount = transactionAmount;
		this.beneficiaryAccountNumber = beneficiaryAccountNumber;
		//this.transactiontype = transactiontype;
	}

	public double getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public long getBeneficiaryAccountNumber() {
		return beneficiaryAccountNumber;
	}

	public void setBeneficiaryAccountNumber(long beneficiaryAccountNumber) {
		this.beneficiaryAccountNumber = beneficiaryAccountNumber;
	}

	/*public TransactionType getTransactiontype() {
		return transactiontype;
	}

	public void setTransactiontype(TransactionType transactiontype) {
		this.transactiontype = transactiontype;
	}*/

	@Override
	public String toString() {
		return "TransactionTransferDTO [transactionAmount=" + transactionAmount + ", beneficiaryAccountNumber="
				+ beneficiaryAccountNumber + "]";
	}

	

}
