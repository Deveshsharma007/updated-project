package com.hexaware.entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="bank")
public class Bank {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long bankId;
	private String bankName;
	private String bankBranch;
	private String ifscCode;
	private String bankCity;
	private String bankState;
	@OneToMany(cascade=CascadeType.ALL)
	@JoinTable(name="bank_bankEmployee_mapping",joinColumns=@JoinColumn(name="bank_id"),inverseJoinColumns=@JoinColumn(name="employee_id"))
	private List<BankEmployee> employeeList=new ArrayList<>();
	
	public Bank() {
		super();
		// TODO Auto-generated constructor stub
	}
    
	public Bank(Long bankId, String bankName, String bankBranch, String ifscCode, String bankCity, String bankState) {
		super();
		this.bankId = bankId;
		this.bankName = bankName;
		this.bankBranch = bankBranch;
		this.ifscCode = ifscCode;
		this.bankCity = bankCity;
		this.bankState = bankState;
	}

	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankBranch() {
		return bankBranch;
	}
	public void setBankBranch(String bankBranch) {
		this.bankBranch = bankBranch;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getBankCity() {
		return bankCity;
	}
	public void setBankCity(String bankCity) {
		this.bankCity = bankCity;
	}
	public String getBankState() {
		return bankState;
	}
	public void setBankState(String bankState) {
		this.bankState = bankState;
	}
	public Long getBankId() {
		return bankId;
	}

	public void setBankId(Long bankId) {
		this.bankId = bankId;
	}

	@Override
	public String toString() {
		return "Bank [bankId=" + bankId + ", bankName=" + bankName + ", bankBranch=" + bankBranch + ", ifscCode="
				+ ifscCode + ", bankCity=" + bankCity + ", bankState=" + bankState + "]";
	}
     


    
}