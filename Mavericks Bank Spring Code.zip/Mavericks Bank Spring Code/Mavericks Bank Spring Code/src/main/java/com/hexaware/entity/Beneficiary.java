package com.hexaware.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table
public class Beneficiary {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long beneficiaryId;
	private long beneficiaryAccountNumber;
	private String beneficiaryName;
	private String beneficiaryBankName;
	private String beneficiaryBranch;
	private String beneficiaryIfscCode;
	
	@ManyToOne
	@JoinColumn(name="account_number")
	private Account account;
	
	public Beneficiary() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Beneficiary(long beneficiaryId, long beneficiaryAccountNumber, String beneficiaryName,
			String beneficiaryBankName, String beneficiaryBranch, String beneficiaryIfscCode, Account account) {
		super();
		this.beneficiaryId = beneficiaryId;
		this.beneficiaryAccountNumber = beneficiaryAccountNumber;
		this.beneficiaryName = beneficiaryName;
		this.beneficiaryBankName = beneficiaryBankName;
		this.beneficiaryBranch = beneficiaryBranch;
		this.beneficiaryIfscCode = beneficiaryIfscCode;
		this.account = account;
	}

	public long getBeneficiaryId() {
		return beneficiaryId;
	}

	public void setBeneficiaryId(long beneficiaryId) {
		this.beneficiaryId = beneficiaryId;
	}

	public long getBeneficiaryAccountNumber() {
		return beneficiaryAccountNumber;
	}

	public void setBeneficiaryAccountNumber(long beneficiaryAccountNumber) {
		this.beneficiaryAccountNumber = beneficiaryAccountNumber;
	}

	public String getBeneficiaryName() {
		return beneficiaryName;
	}

	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	public String getBeneficiaryBankName() {
		return beneficiaryBankName;
	}

	public void setBeneficiaryBankName(String beneficiaryBankName) {
		this.beneficiaryBankName = beneficiaryBankName;
	}

	public String getBeneficiaryBranch() {
		return beneficiaryBranch;
	}

	public void setBeneficiaryBranch(String beneficiaryBranch) {
		this.beneficiaryBranch = beneficiaryBranch;
	}

	public String getBeneficiaryIfscCode() {
		return beneficiaryIfscCode;
	}

	public void setBeneficiaryIfscCode(String beneficiaryIfscCode) {
		this.beneficiaryIfscCode = beneficiaryIfscCode;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	@Override
	public String toString() {
		return "Beneficiary [beneficiaryId=" + beneficiaryId + ", beneficiaryAccountNumber=" + beneficiaryAccountNumber
				+ ", beneficiaryName=" + beneficiaryName + ", beneficiaryBankName=" + beneficiaryBankName
				+ ", beneficiaryBranch=" + beneficiaryBranch + ", beneficiaryIfscCode=" + beneficiaryIfscCode
				+ ", account=" + account + "]";
	}
	
}	