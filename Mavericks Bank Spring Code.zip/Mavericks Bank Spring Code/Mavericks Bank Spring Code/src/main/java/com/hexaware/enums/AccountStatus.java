package com.hexaware.enums;

public enum AccountStatus {
	INACTIVE,ACTIVE,CLOSED,CLOSEREQUEST

}
