package com.hexaware.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hexaware.entity.BankEmployee;

public interface BankEmployeeRepository extends JpaRepository<BankEmployee,Long>{
	
	public BankEmployee findByPanCardNumber(String pancardnumber);

}
