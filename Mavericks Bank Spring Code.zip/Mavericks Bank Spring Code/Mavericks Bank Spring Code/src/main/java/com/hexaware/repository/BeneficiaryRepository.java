package com.hexaware.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hexaware.entity.Beneficiary;

public interface BeneficiaryRepository extends JpaRepository<Beneficiary,Long>{
	public Beneficiary findByBeneficiaryAccountNumber(long beneficiaryaccountnumber); 
   
}
