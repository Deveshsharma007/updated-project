package com.hexaware.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hexaware.entity.Customer;



public interface CustomerRepository extends JpaRepository<Customer,Long>{
	
	
	public List<Customer>findBycustomerNameContaining(String name);
	public Customer findByAadharNumber(String aadharnumber);
	

}
