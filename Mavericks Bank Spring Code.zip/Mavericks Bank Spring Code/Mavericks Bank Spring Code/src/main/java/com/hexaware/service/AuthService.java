package com.hexaware.service;

import com.hexaware.dto.JWTAuthResponse;
import com.hexaware.dto.LoginDto;
import com.hexaware.dto.RegisterDto;

public interface AuthService {
	JWTAuthResponse login(LoginDto dto);
	String register(RegisterDto dto);
	String registerEmployee(RegisterDto dto);
}