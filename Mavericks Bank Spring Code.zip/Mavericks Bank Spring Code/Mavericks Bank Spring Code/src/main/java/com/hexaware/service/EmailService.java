package com.hexaware.service;

import jakarta.mail.MessagingException;

public interface EmailService {
	String sendMail(String to,String subject,String body) throws MessagingException;
 
}