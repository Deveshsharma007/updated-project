package com.hexaware.serviceimplementation;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hexaware.customexceptions.AccountAlreadyExistsException;
import com.hexaware.customexceptions.ResourceNotFoundException;
import com.hexaware.dto.AllTransactionDTO;
import com.hexaware.dto.BankEmployeeAddDTO;
import com.hexaware.dto.InOutDTO;
import com.hexaware.dto.LoanResponseDTO;
import com.hexaware.entity.Account;
import com.hexaware.entity.Bank;
import com.hexaware.entity.BankEmployee;
import com.hexaware.entity.Loan;
import com.hexaware.entity.LoanOption;
import com.hexaware.entity.Transaction;
import com.hexaware.enums.AccountStatus;
import com.hexaware.enums.LoanStatus;
import com.hexaware.enums.TransactionType;
import com.hexaware.repository.AccountRepository;
import com.hexaware.repository.BankEmployeeRepository;
import com.hexaware.repository.BankRepository;
import com.hexaware.repository.CustomerRepository;
import com.hexaware.repository.LoanOptionRepository;
import com.hexaware.repository.LoanRepository;
import com.hexaware.repository.TransactionRepository;
import com.hexaware.service.BankEmployeeService;

@Service
public class BankEmployeeServiceImpl implements BankEmployeeService {
	private BankEmployeeRepository employeeRepo;
	@Autowired
	private LoanOptionRepository loanOptionRepo;
	@Autowired
	private AccountRepository accountRepo;
	@Autowired
	private BankRepository bankRepo;
	@Autowired
	private CustomerRepository customerRepo;
	@Autowired
	private TransactionRepository transactionRepo;
	@Autowired
	private ModelMapper modelMapper;
	@Autowired
	private LoanRepository loanRepo;

	public final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	public BankEmployeeServiceImpl(BankEmployeeRepository employeeRepo) {
		super();
		this.employeeRepo = employeeRepo;
	}

	@Override
	public BankEmployeeAddDTO addEmployee(long id, BankEmployeeAddDTO emp) throws AccountAlreadyExistsException {
		// TODO Auto-generated method stub
		// Bank bank=bankRepo.findById((long) 1).get();
		// emp.setBank(bank);
		BankEmployee obj = modelMapper.map(emp, BankEmployee.class);
		String pancard = obj.getPanCardNumber();
		BankEmployee returnPan = employeeRepo.findByPanCardNumber(pancard);
		if (returnPan == null) {
			Optional<Bank> opt = bankRepo.findById(id);
			Bank bankobj = opt.get();
			obj.setBank(bankobj);
			obj.setEmployeeStatus(AccountStatus.ACTIVE);
			employeeRepo.save(obj);
			BankEmployeeAddDTO returnObj = modelMapper.map(obj, BankEmployeeAddDTO.class);
			return returnObj;
		} else {
			throw new AccountAlreadyExistsException("Employee", "Pancard Number", pancard);
		}

	}

	@Override
	public LoanOption addLoanOptionDetails(LoanOption loanoption) {
		// TODO Auto-generated method stub
		return loanOptionRepo.save(loanoption);
	}

	@Override
	public String activateAccount(long accountnumber) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		Account accountObj = accountRepo.findById(accountnumber).get();
		if (accountObj == null) {
			throw new ResourceNotFoundException("Account", "Number", accountnumber);
		} else {
			if (accountObj.getAccountStatus() == AccountStatus.INACTIVE) {
				accountObj.setAccountStatus(AccountStatus.ACTIVE);
				accountRepo.save(accountObj);
				return "Account Activated";
			} else {
				return "Account is already active";
			}
		}

	}

	@Override
	public String closeAccount(long accountnumber) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		Account accountObj = accountRepo.findById(accountnumber).get();
		if (accountObj == null) {
			throw new ResourceNotFoundException("Account", "Number", accountnumber);
		} else {
			if (accountObj.getAccountStatus() == AccountStatus.CLOSEREQUEST) {
				accountObj.setAccountStatus(AccountStatus.CLOSED);
				accountRepo.save(accountObj);
				/*
				 * Customer cusobj=accountObj.getCustomer();
				 * List<Account>accountList=cusobj.getAccountList();
				 * accountList.remove(accountObj); accountRepo.delete(accountObj);
				 */
				return "Account Closed/Deleted";
			} else {
				return "Account is already active";
			}
		}

	}

	@Override
	public List<AllTransactionDTO> allTransaction() {
		// TODO Auto-generated method stub
		 Sort sortByTransactionidDesc = Sort.by(Sort.Order.desc("transactionID"));
		List<Transaction> obj = transactionRepo.findAll(sortByTransactionidDesc);
		return obj.stream().map(transactionlist -> modelMapper.map(transactionlist, AllTransactionDTO.class))
				.collect(Collectors.toList());
	}

	@Override
	public List<AllTransactionDTO> allTransactionOfAccount(long accountnumber) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		double totalInBound = 0, totalOutBound = 0;
		Optional<Account> accountOpt = accountRepo.findById(accountnumber);
		if (accountOpt.isPresent()) {
			Account accountObj = accountOpt.get();
			List<Transaction> transactionList = accountObj.getTransactionList();
			return transactionList.stream().map(transaction -> modelMapper.map(transaction, AllTransactionDTO.class))
					.collect(Collectors.toList());
		} else
			throw new ResourceNotFoundException("Account", "Number", accountnumber);

	}

	@Override
	public InOutDTO totalCalculation(long accountnumber) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		Optional<Account> accountOpt = accountRepo.findById(accountnumber);
		if (accountOpt.isPresent()) {
			Account accountObj = accountOpt.get();
			List<Transaction> transactionList = accountObj.getTransactionList();
			double totalInBound = 0, totalOutBound = 0, loan = 0;
			for (Transaction transaction : transactionList) {
				if (TransactionType.DEPOSIT.equals(transaction.getTransactionType())) {
					totalInBound += transaction.getTransactionAmount();
				} else if (TransactionType.LOAN.equals(transaction.getTransactionType())) {
					loan += transaction.getTransactionAmount();
				} else {
					totalOutBound += transaction.getTransactionAmount();
				}
			}
			InOutDTO obj = new InOutDTO(totalInBound, totalOutBound, loan);

			return obj;
		} else
			throw new ResourceNotFoundException("Account", "Number", accountnumber);
	}

	@Override
	public List<LoanResponseDTO> allLoanApplications() {
		// TODO Auto-generated method stub
		List<Loan> loanList = loanRepo.findAll();

		return loanList.stream().map(loan -> modelMapper.map(loan, LoanResponseDTO.class)).collect(Collectors.toList());
	}

	@Override
	public String loanApproval(long LoanId) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		Optional<Loan> loanOpt = loanRepo.findById(LoanId);
		if (loanOpt.isPresent()) {
			Loan loanObj = loanOpt.get();
			Account accountObj = loanObj.getAccount();
			if ((accountObj.getAccountStatus() == AccountStatus.ACTIVE)&&(loanObj.getLoanStatus()==LoanStatus.APPLIED)) {
				accountObj.setAccountBalance(accountObj.getAccountBalance() + loanObj.getLoanAmount());

				Transaction tranObj = new Transaction(LocalDate.now(), 0, TransactionType.LOAN, loanObj.getLoanAmount(),
						accountObj.getAccountNumber(), accountObj, null);
				List<Loan> loanList = accountObj.getLoanList();
				/*
				 * for (Loan obj : loanList) { if ((obj.getLoanStatus() ==
				 * LoanStatus.APPLIED)&&(loanObj.getLoanID()==LoanId)) {
				 * obj.setLoanStatus(LoanStatus.APPROVED); } }
				 */
				// loanList.forEach((p)->{LOGGER.log(java.util.logging.Level.INFO,""+p);});
				loanObj.setLoanStatus(LoanStatus.APPROVED);
				accountObj.setLoanList(loanList);
				List<Transaction> tranList = new ArrayList<>();
				tranList = accountObj.getTransactionList();
				tranList.add(tranObj);
				accountObj.setTransactionList(tranList);
				transactionRepo.save(tranObj);
				accountRepo.save(accountObj);
				loanRepo.save(loanObj);
				return "Loan Approved";
			} else {
				return "Account is not active";
			}
		} else
			throw new ResourceNotFoundException("Loan", "Id", LoanId);

	}

	// This Controller is in bank controller
	@Override
	public List<BankEmployeeAddDTO> displayAllEmployee() {
		// TODO Auto-generated method stub
		List<BankEmployee> bankEmpList = employeeRepo.findAll();
		return bankEmpList.stream().map(emplist -> modelMapper.map(emplist, BankEmployeeAddDTO.class))
				.collect(Collectors.toList());
	}

	@Override
	public String deleteEmployee(long empid) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		BankEmployee obj = employeeRepo.findById(empid).get();
		if (obj == null) {
			throw new ResourceNotFoundException("Employee", "Id", empid);
		} else {
			obj.setBank(null);
			employeeRepo.save(obj);
			employeeRepo.deleteById(empid);
			return "Deletion Successfull";
		}
	}

	@Override
	public String loanReject(long loanId) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		Optional<Loan> loanOpt = loanRepo.findById(loanId);
		if (loanOpt.isEmpty()) {
			throw new ResourceNotFoundException("Loan", "Id", loanId);
		} else {
			Loan loanObj = loanOpt.get();
			Account accountObj = loanObj.getAccount();
			if ((accountObj.getAccountStatus() == AccountStatus.ACTIVE || accountObj.getAccountStatus()==AccountStatus.CLOSED)
					&& (loanObj.getLoanStatus() == LoanStatus.APPLIED)) {
				loanObj.setLoanStatus(LoanStatus.REJECTED);
				List<Loan> loanList = accountObj.getLoanList();
				accountRepo.save(accountObj);
				loanRepo.save(loanObj);

			} else {
				return "Account Inactive or loan is approved already";
			}
			return "Loan Rejected";
		}
	}

	@Override
	public BankEmployeeAddDTO findEmployee(long empId) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		Optional<BankEmployee> emp=employeeRepo.findById(empId);
		if (emp.isEmpty()) {
			throw new ResourceNotFoundException("Employee does not exists", "Id", empId);
		} else {
			BankEmployee empObj = emp.get();
			BankEmployeeAddDTO obj=modelMapper.map(empObj, BankEmployeeAddDTO.class);
		return obj;
		}
	}

}
