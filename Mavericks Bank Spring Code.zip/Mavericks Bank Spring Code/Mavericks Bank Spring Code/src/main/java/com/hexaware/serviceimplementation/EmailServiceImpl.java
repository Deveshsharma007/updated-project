package com.hexaware.serviceimplementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.hexaware.service.EmailService;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class EmailServiceImpl implements EmailService{
	
 
	   @Autowired
	    private JavaMailSender mailSender;
	
	@Override
	@Async
	public String sendMail(String to,String subject,String body) throws MessagingException {
		// TODO Auto-generated method stub
MimeMessage mimeMessage=mailSender.createMimeMessage();
		
		MimeMessageHelper mhelper=new MimeMessageHelper(mimeMessage,true);
		
//		mhelper.setFrom("aswinchander544@gmail.com");
		mhelper.setTo(to);
		mhelper.setText(body);
		mhelper.setSubject(subject);
		mailSender.send(mimeMessage);
		
		return null;
	}
 
}