package com.hexaware.serviceimplementation;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexaware.dto.OtherBankDetailsAddDTO;
import com.hexaware.entity.OtherBankDetails;
import com.hexaware.repository.OtherBankDetailRepository;
import com.hexaware.service.OtherBankDetailService;
@Service
public class OtherBankDetailServiceImpl implements OtherBankDetailService {
	private OtherBankDetailRepository otherRepo;
	@Autowired
	private ModelMapper modelMapper;

	public OtherBankDetailServiceImpl(OtherBankDetailRepository otherRepo) {
		super();
		this.otherRepo = otherRepo;
	}

	@Override
	public OtherBankDetailsAddDTO addOtherBank(OtherBankDetailsAddDTO otherBank) {
		// TODO Auto-generated method stub
		OtherBankDetails obj=modelMapper.map(otherBank, OtherBankDetails.class);
		OtherBankDetails returnedObj=otherRepo.save(obj);
		OtherBankDetailsAddDTO dtoObj=modelMapper.map(returnedObj, OtherBankDetailsAddDTO.class);
		return dtoObj;
	}

	@Override
	public List<String> findByotherBankNameContaining(String name) {
		// TODO Auto-generated method stub
		List<String> obj=otherRepo.findByotherBankNameContaining(name);
		
		return obj;
	}

	@Override
	public List<String> findBankBranch(String bankname) {
		// TODO Auto-generated method stub
		
		return otherRepo.findBankBranch(bankname);
	}

	@Override
	public String getIfsccode(String bankname,String branchname) {
		// TODO Auto-generated method stub
		return otherRepo.getIfsccode(bankname,branchname);
	}
	

}
