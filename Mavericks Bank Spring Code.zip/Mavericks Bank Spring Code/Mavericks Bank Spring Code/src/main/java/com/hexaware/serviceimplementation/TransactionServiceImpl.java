package com.hexaware.serviceimplementation;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexaware.customexceptions.LessBalanceException;
import com.hexaware.customexceptions.ResourceNotFoundException;
import com.hexaware.dto.AllTransactionDTO;
import com.hexaware.dto.TransactionDepositDTO;
import com.hexaware.dto.TransactionTransferDTO;
import com.hexaware.entity.Account;
import com.hexaware.entity.Transaction;
import com.hexaware.enums.AccountStatus;
import com.hexaware.enums.TransactionType;
import com.hexaware.repository.AccountRepository;
import com.hexaware.repository.BeneficiaryRepository;
import com.hexaware.repository.TransactionRepository;
import com.hexaware.service.TransactionService;

@Service
public class TransactionServiceImpl implements TransactionService {
	@Autowired
	TransactionRepository transactionRepo;
	@Autowired
	AccountRepository accountRepo;
	@Autowired
	BeneficiaryRepository beneficiaryRepo;
	@Autowired
	ModelMapper modelMapper;

	@Override
	public String transferAmount(long accountnumber, TransactionTransferDTO transaction)
			throws ResourceNotFoundException, LessBalanceException {
		// TODO Auto-generated method stub
		Transaction tranObj = modelMapper.map(transaction, Transaction.class);
		Optional<Account> accountOpt = accountRepo.findById(accountnumber);
		if (accountOpt.isEmpty()) {
			throw new ResourceNotFoundException("Account", "Number", accountnumber);
		} else {
			Account accountObj = accountOpt.get();
			if(accountObj.getAccountStatus()==AccountStatus.ACTIVE) {
			if (accountObj.getAccountBalance() < tranObj.getTransactionAmount()) {
				throw new LessBalanceException("Account Balance is less");
			} else {
				accountObj.setAccountBalance(accountObj.getAccountBalance() - tranObj.getTransactionAmount());
				tranObj.setAccount(accountObj);
				List<Transaction> tranList = accountObj.getTransactionList();
				tranObj.setTransactionType(TransactionType.TRANSFER);
				tranObj.setDate();
				tranList.add(tranObj);
				accountObj.setTransactionList(tranList);
				transactionRepo.save(tranObj);
				return "Transaction Successful";
			}
			}
			else 
				return "Account is Inactive";
		}
	}

	@Override
	public String depositAmount(long accountnumber, TransactionDepositDTO transaction)
			throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		Optional<Account> accountopt = accountRepo.findById(accountnumber);
		if (accountopt.isEmpty()) {
			throw new ResourceNotFoundException("Account", "Number", accountnumber);
		} else {
			Account accountObj = (Account) accountopt.get();
			if(accountObj.getAccountStatus()!=AccountStatus.ACTIVE) {
				return "Account is inactive";
			}else {
			Transaction tranObj = modelMapper.map(transaction, Transaction.class);
			tranObj.setAccount(accountObj);
			List<Transaction> tranList = accountObj.getTransactionList();
			tranObj.setTransactionType(TransactionType.DEPOSIT);
			tranObj.setDate();
			tranObj.setBeneficiaryAccountNumber(accountnumber);
			tranList.add(tranObj);
			accountObj.setAccountBalance(tranObj.getTransactionAmount() + accountObj.getAccountBalance());
			accountObj.setTransactionList(tranList);
			transactionRepo.save(tranObj);
			return "Deposit Successfull";
		}
			}

	}

	@Override
	public String withdrawAmount(long accountnumber, TransactionDepositDTO transaction)
			throws ResourceNotFoundException, LessBalanceException {
		// TODO Auto-generated method stub
		Optional<Account> accountopt = accountRepo.findById(accountnumber);
		if (accountopt.isEmpty()) {
			throw new ResourceNotFoundException("Account", "Number", accountnumber);
		} else {
			Account accountObj = (Account) accountopt.get();
			if(accountObj.getAccountStatus()!=AccountStatus.ACTIVE) {
				return "Account is inactive";
			}else {
			Transaction tranObj = modelMapper.map(transaction, Transaction.class);
			if (accountObj.getAccountBalance() < tranObj.getTransactionAmount()) {
				throw new LessBalanceException("Account Balance is less");
			} else {
				tranObj.setAccount(accountObj);
				List<Transaction> tranList = accountObj.getTransactionList();
				tranObj.setTransactionType(TransactionType.WITHDRAW);
				tranObj.setDate();
				tranObj.setBeneficiaryAccountNumber(accountnumber);
				tranList.add(tranObj);
				accountObj.setAccountBalance(accountObj.getAccountBalance() - tranObj.getTransactionAmount());
				accountObj.setTransactionList(tranList);
				;
				transactionRepo.save(tranObj);
				return "Withdraw Successfull";
			}
			}
		}

	}

	public List<AllTransactionDTO> view10Transaction(long accountnumber) {
		List<Transaction> tranList = transactionRepo.view10Transaction(accountnumber);
		return tranList.stream().map(tList -> modelMapper.map(tList, AllTransactionDTO.class))
				.collect(Collectors.toList());

	}

	@Override
	public List<AllTransactionDTO> TransactionBetweenTwoDates(long accountnumber, LocalDate startdate,
			LocalDate enddate) {
		// TODO Auto-generated method stub
		List<Transaction> tranList = transactionRepo.TransactionBetweenTwoDates(accountnumber, startdate, enddate);
		return tranList.stream().map(tList -> modelMapper.map(tList, AllTransactionDTO.class))
				.collect(Collectors.toList());
	}

	@Override
	public List<AllTransactionDTO> TransactionForLastMonth(long accountnumber, LocalDate startdate) {
		// TODO Auto-generated method stub
		List<Transaction> tranList = transactionRepo.TransactionForLastMonth(accountnumber, startdate);
		return tranList.stream().map(tList -> modelMapper.map(tList, AllTransactionDTO.class))
				.collect(Collectors.toList());
	}

}
