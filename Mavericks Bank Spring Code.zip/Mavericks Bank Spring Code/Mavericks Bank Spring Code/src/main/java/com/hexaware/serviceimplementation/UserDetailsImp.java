/*package com.hexaware.serviceimplementation;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.hexaware.entity.User;
import com.hexaware.repository.UserRepository;

@Service
public class UserDetailsImp implements UserDetailsService{

	@Autowired
	private UserRepository repo;
	@Override
	public User loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		return repo.findByuserName(username);
				
	}

}
*/